import AdmissionForm from './Admissionform.js'; // Import the new component
import './App.css'; // Make sure your App.css is set up correctly

function App() {
  return (
    <div className="App">
      <AdmissionForm />
    </div>
  );
}

export default App;
