import { useState } from 'react';
import './AdmissionForm.css'; // Make sure to create this CSS file

function AdmissionForm() {
    const [formData, setFormData] = useState({
        fullName: '',
        dateOfBirth: '',
        gender: '',
        phoneNumber: '',
        email: '',
        sscPercentage: '',
        hscPercentage: '',
        ugCgpa: '',
        course: '',
        declaration: false,
    });

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: type === 'checkbox' ? checked : value
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (formData.declaration) {
            console.log('Form Submitted Successfully:', formData);
            alert('Form submitted successfully!');
            // You can add logic here to send data to a backend server
        } else {
            alert('Please agree to the declaration.');
        }
    };

    return (
        <div className="admission-form-container">
            <form onSubmit={handleSubmit}>
                <h1 className="form-title">College Admission Form</h1>
                
                <fieldset className="form-section">
                    <legend>Personal Details</legend>
                    <div className="form-group">
                        <label htmlFor="fullName">Full Name:</label>
                        <input type="text" id="fullName" name="fullName" value={formData.fullName} onChange={handleChange} required />
                    </div>
                    <div className="form-group">
                        <label htmlFor="dateOfBirth">Date of Birth:</label>
                        <input type="date" id="dateOfBirth" name="dateOfBirth" value={formData.dateOfBirth} onChange={handleChange} required />
                    </div>
                    <div className="form-group">
                        <label htmlFor="gender">Gender:</label>
                        <select id="gender" name="gender" value={formData.gender} onChange={handleChange} required>
                            <option value="">Select...</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div className="form-group">
                        <label htmlFor="phoneNumber">Phone Number:</label>
                        <input type="tel" id="phoneNumber" name="phoneNumber" value={formData.phoneNumber} onChange={handleChange} required />
                    </div>
                    <div className="form-group">
                        <label htmlFor="email">Email:</label>
                        <input type="email" id="email" name="email" value={formData.email} onChange={handleChange} required />
                    </div>
                </fieldset>

                <fieldset className="form-section">
                    <legend>Educational Qualifications</legend>
                    <div className="form-group">
                        <label htmlFor="sscPercentage">SSC (%):</label>
                        <input type="text" id="sscPercentage" name="sscPercentage" value={formData.sscPercentage} onChange={handleChange} required />
                    </div>
                    <div className="form-group">
                        <label htmlFor="hscPercentage">HSC (%):</label>
                        <input type="text" id="hscPercentage" name="hscPercentage" value={formData.hscPercentage} onChange={handleChange} required />
                    </div>
                    <div className="form-group">
                        <label htmlFor="ugCgpa">UG/CGPA (if any):</label>
                        <input type="text" id="ugCgpa" name="ugCgpa" value={formData.ugCgpa} onChange={handleChange} />
                    </div>
                </fieldset>

                <fieldset className="form-section">
                    <legend>Course Selection</legend>
                    <div className="form-group">
                        <label htmlFor="course">Select Course:</label>
                        <select id="course" name="course" value={formData.course} onChange={handleChange} required>
                            <option value="">Select...</option>
                            <option value="Engineering">Engineering</option>
                            <option value="Medicine">Medicine</option>
                            <option value="Arts">Arts</option>
                            <option value="Commerce">Commerce</option>
                        </select>
                    </div>
                </fieldset>

                <fieldset className="form-section">
                    <legend>Declaration</legend>
                    <div className="form-group-checkbox">
                        <input type="checkbox" id="declaration" name="declaration" checked={formData.declaration} onChange={handleChange} />
                        <label htmlFor="declaration">I hereby declare that all the information provided is true to the best of my knowledge.</label>
                    </div>
                </fieldset>
                
                <button type="submit" className="submit-button">Submit Form</button>
            </form>
        </div>
    );
}

export default AdmissionForm;
