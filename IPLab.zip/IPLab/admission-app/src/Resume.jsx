import './Resume.css';


const resumeData = {
  name: 'VEDANT POTBHARE',
  contact: {
    address: 'Chhani , Vadodara, Gujarat-391740',
    phone: '+91 9999555666',
    email: 'vedpotbhare11@gmail.com',
  },
  summary:
    'Motivated and aspiring IT engineering student with a strong foundation in programming, data structures, and software development. Eager to apply my skills to solve real-world problems and contribute to innovative technology solutions.',
  skills: [
    {
      category: 'Frontend',
      tools: 'HTML, CSS, JavaScript, React',
    },
    {
      category: 'Backend',
      tools: 'Java, Python, Node.js',
    },
    {
      category: 'Database',
      tools: 'SQL (MySQL), MongoDB',
    },
  ],
  certifications: [
    'NPTEL Certification in Database Management Systems - Elite Grade',
    'Full Stack Java Developer Certificate (Java, Spring Boot, MySQL)',
    'React Basics Certificate - Coursera',
  ],
  education: [
    {
      degree: 'B.E. in Information Technology',
      institution: 'Bharati Vidyapeeth College of Engineering, Navi Mumbai',
      status: 'Pursuing',
    },
    {
      degree: 'Higher Secondary (HSC)',
      institution: 'Podar world School sama, Vadodara',
      status: 'Completed',
    },
    {
      degree: 'Secondary School (SSC)',
      institution: 'Podar World School Sama, Vadodara',
      status: 'Completed',
    },
  ],
  achievements: [
    { name: 'Semester 3 CGPA', grade: '8.50' },
    { name: 'Semester 2 CGPA', grade: '8.10' },
    { name: 'Semester 1 CGPA', grade: '7.80' },
    { name: 'Higher Secondary (HSC)', grade: '80%' },
    { name: 'Secondary School (SSC)', grade: '93%' },
  ],
};


function Resume() {
  return (
    <div className="resume-container">
      <header className="resume-header">
        <h1>{resumeData.name}</h1>
        <div className="contact-info">
          <p>{resumeData.contact.address}</p>
          <p>{resumeData.contact.phone}</p>
          <p>{resumeData.contact.email}</p>
        </div>
      </header>

      <main>
        <section className="resume-section">
          <h2>Summary</h2>
          <p>{resumeData.summary}</p>
        </section>

        <section className="resume-section">
          <h2>Skills</h2>
          {resumeData.skills.map((skill, index) => (
            <div key={index} className="skill-item">
              <strong>{skill.category}:</strong> {skill.tools}
            </div>
          ))}
        </section>

        <section className="resume-section">
          <h2>Certificates</h2>
          <ul>
            {resumeData.certifications.map((cert, index) => (
              <li key={index}>{cert}</li>
            ))}
          </ul>
        </section>

        <section className="resume-section">
          <h2>Education and Training</h2>
          {resumeData.education.map((edu, index) => (
            <div key={index} className="education-item">
              <strong>{edu.degree}</strong> - <em>{edu.status}</em>
              <p>{edu.institution}</p>
            </div>
          ))}
        </section>
        
        <section className="resume-section">
          <h2>Achievements</h2>
          <div className="achievements-grid">
             {resumeData.achievements.map((ach, index) => (
               <div key={index} className="achievement-item">
                 <span>{ach.name}</span>
                 <strong>{ach.grade}</strong>
               </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}

export default Resume;