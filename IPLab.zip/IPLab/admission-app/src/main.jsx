import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx'; // Importing your main App component

// This is the standard entry point for a React application.
// It finds the 'root' div in your index.html file and tells React to render your app inside it.
ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);