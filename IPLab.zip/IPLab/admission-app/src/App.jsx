import AdmissionForm from './Admissionform.jsx'; // Import the new component


function App() {
  return (
    <div className="App">
      <AdmissionForm />
    </div>
  );
}

export default App;
